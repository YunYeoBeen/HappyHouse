export default {
  GET_BOARD_SEARCH: "getBoardBySearch",
  SET_BOARD_SEARCH: "setBoardBySearch",
};
