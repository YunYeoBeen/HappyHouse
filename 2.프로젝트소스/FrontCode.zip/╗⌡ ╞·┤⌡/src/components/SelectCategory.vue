<template>
  <select name="category" id="category" class="form-select">
    <option value="">지역별</option>
    <option value="">아파트별</option>
  </select>
</template>

<script>
export default {};
</script>
