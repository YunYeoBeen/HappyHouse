-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: happyhouse
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `qna`
--

DROP TABLE IF EXISTS `qna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `qna` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `content` longtext NOT NULL,
  `writer` varchar(50) NOT NULL,
  `writedate` date DEFAULT NULL,
  `readcnt` int NOT NULL DEFAULT '0',
  `totalComment` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qna`
--

LOCK TABLES `qna` WRITE;
/*!40000 ALTER TABLE `qna` DISABLE KEYS */;
INSERT INTO `qna` VALUES (6,'죽전동 수지구 코드는 뭔가요?','죽전동 수지구 코드는 뭔가요?','duwns7899','2022-05-19',482,0),(8,'zzzzzzzzzzzzz','asdasdasdasd','administrator','2022-05-23',37,0),(9,'ㅁㄴㅇㅁㄴㅇ','ㅁㄴㅇㅁㄴㅇ','administrator','2022-05-23',20,0),(12,'이번주 금요일 기대!!','이번주 금요일 기대!!','assy110','2022-05-23',28,0),(14,'하이요 새로 등록해요','등록합니다','assy110','2022-05-23',0,0),(15,'관리자는 자유게시판에서도 등록 가능','관리자는 자유게시판에서도 등록 가능','admin001','2022-05-23',1,0),(16,'관리자입니다.','관리자입니다.','admin001','2022-05-24',0,0),(17,'질문있어요!','질문있어요!','assy110','2022-05-24',0,0),(18,'123123','123123','assy110','2022-05-24',0,0),(19,'12323','213123','assy110','2022-05-24',0,0),(20,'테스트해봅니다.','테스트해봅니다.','assy110','2022-05-24',0,0),(21,'ㅋㅋㅋㅋㅋㅋ','ㅋㅋㅋㅋㅋ','admin001','2022-05-24',0,0);
/*!40000 ALTER TABLE `qna` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-26 11:41:30
